# *SNAKISMS*

This is the code and process repository for the game *SNAKISMS*. See the [information page](info/) for more detail.
