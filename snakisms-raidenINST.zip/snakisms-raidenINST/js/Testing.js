
BasicGame.Testing = function (game) {

};

BasicGame.Testing.prototype = {

	init: function () {

	},

	create: function () {
		this.add.text(100, 100, `浪漫主义`, {
			fill: `yellow`,
			fontSize: 64
		});
	}

};
