# SNAKISMS

Not my most well-documented project but there is

* A list of [to-dos](./to-do.md)
* A [design document](./design.md) tracing my ideas about the different variations
